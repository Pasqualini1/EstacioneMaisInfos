package com.estacioneMais.repository;

import com.estacioneMais.model.VagasDisp;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface VagasDispRepository extends JpaRepository<VagasDisp, Long> {

    /**
     * Busca a primeira (e única) entidade de VagasDisp salva no banco.
     * Só haverá uma linha nesta tabela, contendo o total de vagas do pátio.
     */
    Optional<VagasDisp> findFirstByOrderByIdAsc();
}