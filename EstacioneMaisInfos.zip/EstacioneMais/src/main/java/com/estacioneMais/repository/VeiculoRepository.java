package com.estacioneMais.repository;

import com.estacioneMais.model.Veiculo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/*
 * Interface de Repositório para a entidade {@link Veiculo}.
 *
 * Estendendo {@code JpaRepository}, esta interface herda automaticamente todos
 * os métodos padrão de acesso a dados (salvar, buscar, deletar, etc.) para a
 * entidade Veiculo, com o Spring Data JPA cuidando da implementação em tempo de execução.
 */
@Repository
public interface VeiculoRepository extends JpaRepository<Veiculo, Long> {

    /*
     * Busca o primeiro veículo encontrado com a placa especificada.
     * Como a placa é um campo único na tabela de veículos, este método é a forma
     * padrão de verificar a existência ou recuperar os dados de um veículo específico.
     *
     * @param placa A placa a ser pesquisada.
     * @return Um {@code Optional} que conterá o Veiculo se ele for encontrado,
     * ou estará vazio caso contrário.
     */
    Optional<Veiculo> findFirstByPlaca(String placa);
}