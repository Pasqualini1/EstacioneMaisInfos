package com.estacioneMais.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/*
 * Exceção customizada para representar situações em que um recurso solicitado
 * não foi encontrado no sistema.
 *
 * Ao estender {@code RuntimeException}, ela se torna uma exceção "não checada", o que
 * simplifica o código, pois não exige blocos try-catch obrigatórios.
 *
 * A anotação {@code @ResponseStatus(HttpStatus.NOT_FOUND)} é a parte mais importante:
 * ela instrui o Spring a automaticamente retornar uma resposta HTTP com o status 404 Not Found
 * sempre que essa exceção for lançada por um controller e não for tratada de outra forma.
 * Isso centraliza e padroniza o tratamento de erros de "não encontrado".
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException {

    /*
     * Construtor da exceção.
     *
     * @param message A mensagem detalhando o erro, que será incluída na
     * resposta da API (ex: "Veículo com placa XYZ-1234 não encontrado.").
     */
    public ResourceNotFoundException(String message) {
        super(message);
    }
}