package com.estacioneMais.controller;

import com.estacioneMais.dto.StatusPatioDTO; // --- NOVO: Import do DTO ---
import com.estacioneMais.dto.VeiculoDTO;
import com.estacioneMais.dto.VeiculoEntradaManualDTO;
import com.estacioneMais.service.EstacionamentoService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/estacionamento")
public class EstacionamentoController {

    private final EstacionamentoService estacionamentoService;

    public EstacionamentoController(EstacionamentoService estacionamentoService) {
        this.estacionamentoService = estacionamentoService;
    }

    // --- INÍCIO DO NOVO ENDPOINT PARA A TELA DE PÁTIO ---

    /**
     * Endpoint para a tela de "Status do Pátio".
     * Retorna os contadores de vagas e a lista de veículos ativos
     * com valor e tempo calculados em tempo real.
     */
    @GetMapping("/status-patio")
    public ResponseEntity<StatusPatioDTO> getStatusPatio() {
        StatusPatioDTO statusPatio = estacionamentoService.getStatusPatio();
        return ResponseEntity.ok(statusPatio);
    }

    // --- FIM DO NOVO ENDPOINT ---


    /**
     * NOVO ENDPOINT: Apenas calcula e retorna os dados da saída, sem salvar.
     */
    @GetMapping("/saida/preview/{placa}")
    public ResponseEntity<VeiculoDTO> previewSaida(@PathVariable String placa) {
        VeiculoDTO previewDTO = estacionamentoService.calcularSaida(placa);
        return ResponseEntity.ok(previewDTO);
    }

    /**
     * Endpoint que efetivamente registra a saída no banco de dados.
     */
    @PostMapping("/saida/{placa}")
    public ResponseEntity<VeiculoDTO> registrarSaida(@PathVariable String placa) {
        VeiculoDTO registroFinal = estacionamentoService.registrarSaida(placa);
        return ResponseEntity.ok(registroFinal);
    }

    // --- Outros endpoints (entrada, listar, etc.) sem alterações ---

    @PostMapping("/entrada")
    public ResponseEntity<String> registrarEntradaManual(
            @RequestBody VeiculoEntradaManualDTO entradaDTO) {
        estacionamentoService.registrarEntrada(entradaDTO);
        return ResponseEntity.ok("Entrada do veículo " +
                entradaDTO.placa().toUpperCase() + " registrada com sucesso.");
    }

    @GetMapping("/ativos")
    public ResponseEntity<List<VeiculoDTO>> listarVeiculosAtivos() {
        return ResponseEntity.ok(estacionamentoService.listarVeiculosAtivos());
    }

    @GetMapping("/historico")
    public ResponseEntity<List<VeiculoDTO>> listarHistoricoCompleto() {
        return ResponseEntity.ok(estacionamentoService.listarHistoricoCompleto());
    }

    @GetMapping("/historico/{placa}")
    public ResponseEntity<List<VeiculoDTO>> getHistoricoPorPlaca(@PathVariable String placa) {
        return ResponseEntity.ok(estacionamentoService.gerarRelatorioPorPlaca(placa));
    }

    @GetMapping("/relatorio")
    public ResponseEntity<List<VeiculoDTO>> getRelatorioPorPeriodo(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dataInicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime dataFim) {
        return ResponseEntity.ok(estacionamentoService.buscarRegistrosPorPeriodo(dataInicio, dataFim));
    }
}