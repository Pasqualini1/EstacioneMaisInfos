package com.estacioneMais.service;

import com.estacioneMais.dto.*; // --- NOVO: Importa os novos DTOs (StatusPatioDTO e VeiculoStatusDTO) ---
import com.estacioneMais.exception.ResourceNotFoundException;
import com.estacioneMais.model.Preco;
import com.estacioneMais.model.RegistroEstacionamento;
import com.estacioneMais.model.Veiculo;
import com.estacioneMais.model.VagasDisp; // --- NOVO: Importa o VagasDisp ---
import com.estacioneMais.repository.RegistroEstacionamentoRepository;
import com.estacioneMais.repository.VeiculoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EstacionamentoService {
    private final VeiculoRepository veiculoRepository;
    private final RegistroEstacionamentoRepository registroRepository;
    private final ApiPlacaFipeService consultaExternaService;
    private final PrecoService precoService;
    private final VagasDispService vagasDispService; // --- NOVO: Injeção do VagasDispService ---

    public EstacionamentoService(
            VeiculoRepository veiculoRepository,
            RegistroEstacionamentoRepository registroRepository,
            ApiPlacaFipeService consultaExternaService,
            PrecoService precoService,
            VagasDispService vagasDispService) { // --- NOVO: Adicionado ao construtor ---
        this.veiculoRepository = veiculoRepository;
        this.registroRepository = registroRepository;
        this.consultaExternaService = consultaExternaService;
        this.precoService = precoService;
        this.vagasDispService = vagasDispService; // --- NOVO: Atribuição ---
    }

    // --- INÍCIO DO NOVO MÉTODO PARA A TELA DE PÁTIO ---

    /**
     * Busca todas as informações necessárias para a tela de "Status do Pátio".
     * Calcula vagas, carros no pátio, tempo e valor atual de cada um.
     */
    @Transactional(readOnly = true)
    public StatusPatioDTO getStatusPatio() {
        // 1. Busca o total de vagas configurado
        VagasDisp vagasConfig = vagasDispService.getVagas();
        int totalVagas = vagasConfig.getTotalVagas();

        // 2. Busca todos os registros de veículos que ainda não saíram
        List<RegistroEstacionamento> veiculosAtivos = registroRepository
                .findByHorarioSaidaIsNullOrderByHorarioEntradaDesc();

        LocalDateTime agora = LocalDateTime.now();

        // 3. Mapeia a lista de Registros para a lista de VeiculoStatusDTO
        List<VeiculoStatusDTO> veiculosDTOList = veiculosAtivos.stream().map(registro -> {
            Veiculo veiculo = registro.getVeiculo();

            // 4. Calcula o valor atual (como se fosse sair agora)
            BigDecimal valorAtual = calcularValorTotal(registro.getHorarioEntrada(), agora);

            // 5. Calcula o tempo que o veículo está estacionado
            Duration duracao = Duration.between(registro.getHorarioEntrada(), agora);
            String tempoEstacionado = formatarDuracao(duracao);

            // 6. Monta o DTO de status do veículo
            return new VeiculoStatusDTO(
                    veiculo.getPlaca(),
                    veiculo.getNomeCliente(),
                    veiculo.getTelefoneCliente(),
                    veiculo.getModelo(),
                    veiculo.getCor(),
                    registro.getHorarioEntrada(),
                    tempoEstacionado,
                    valorAtual
            );
        }).collect(Collectors.toList());

        // 7. Calcula os contadores
        int vagasOcupadas = veiculosDTOList.size();
        int vagasDisponiveis = totalVagas - vagasOcupadas;

        // 8. Retorna o DTO principal da tela
        return new StatusPatioDTO(
                totalVagas,
                vagasOcupadas,
                vagasDisponiveis,
                veiculosDTOList
        );
    }

    // --- FIM DO NOVO MÉTODO ---

    /**
     * Calcula o valor da saída sem persistir (salvar) os dados.
     * Usado para pré-visualizar o valor para o operador.
     */
    @Transactional(readOnly = true)
    public VeiculoDTO calcularSaida(String placa) {
        RegistroEstacionamento registro = registroRepository.
                findByVeiculoPlacaAndHorarioSaidaIsNull(placa)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Veículo com a placa " + placa + " não está atualmente no pátio."));

        LocalDateTime horarioSaida = LocalDateTime.now();
        BigDecimal valorCalculado = calcularValorTotal(registro.getHorarioEntrada(), horarioSaida);

        Veiculo v = registro.getVeiculo();
        return new VeiculoDTO(
                v.getNomeCliente(), v.getTelefoneCliente(), v.getPlaca(), v.getModelo(),
                v.getCor(), v.getAno(), registro.getHorarioEntrada(), horarioSaida,
                valorCalculado
        );
    }

    /**
     * Registra a saída de um veículo e salva as informações no banco de dados.
     */
    @Transactional
    public VeiculoDTO registrarSaida(String placa) {
        RegistroEstacionamento registro = registroRepository.
                findByVeiculoPlacaAndHorarioSaidaIsNull(placa)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Veículo com a placa " + placa + " não está atualmente no pátio."));

        LocalDateTime horarioSaida = LocalDateTime.now();
        BigDecimal valorCalculado = calcularValorTotal(registro.getHorarioEntrada(), horarioSaida);

        registro.setHorarioSaida(horarioSaida);
        registro.setValorTotal(valorCalculado);
        RegistroEstacionamento registroSalvo = registroRepository.save(registro);

        return mapearRegistroParaDTO(registroSalvo);
    }

    /**
     * Lógica de cálculo de valor que usa o PrecoService para buscar as regras de preço.
     * --- VERSÃO CORRIGIDA PARA CÁLCULO PROPORCIONAL ---
     */
    private BigDecimal calcularValorTotal(LocalDateTime horarioEntrada, LocalDateTime horarioSaida) {
        // Busca a configuração de preço (ex: R$ 5,00 a cada 60 minutos)
        Preco preco = precoService.getPreco();
        long minutosEstacionado = Duration.between(horarioEntrada, horarioSaida).toMinutes();

        // Se o tempo for zero ou negativo, não há cobrança.
        if (minutosEstacionado <= 0) {
            return BigDecimal.ZERO;
        }

        // Validação para evitar divisão por zero.
        if (preco.getPrecoMinutos() <= 0) {
            throw new IllegalStateException("A 'quantidade de minutos' na configuração de preço deve ser maior que zero.");
        }

        // --- INÍCIO DA LÓGICA CORRIGIDA ---

        // Converte os valores para BigDecimal para cálculos precisos
        BigDecimal valorIntervalo = preco.getPrecoValor();
        BigDecimal minutosIntervalo = new BigDecimal(preco.getPrecoMinutos());
        BigDecimal minutosEstacionadoBD = new BigDecimal(minutosEstacionado);

        // 1. Calcula o valor por minuto.
        // Usamos uma escala maior (ex: 4 casas decimais) para precisão no cálculo intermediário
        // e RoundingMode.HALF_UP que é o arredondamento padrão para finanças.
        BigDecimal valorPorMinuto = valorIntervalo.divide(minutosIntervalo, 4, java.math.RoundingMode.HALF_UP);

        // 2. Calcula o valor total multiplicando o valor por minuto pelo tempo da estadia.
        BigDecimal valorTotal = valorPorMinuto.multiply(minutosEstacionadoBD);

        // 3. Arredonda o resultado final para 2 casas decimais, que é o padrão para moeda (ex: R$ 7,50).
        return valorTotal.setScale(2, java.math.RoundingMode.HALF_UP);

        // --- FIM DA LÓGICA CORRIGIDA ---
    }

    @Transactional
    public void registrarEntrada(VeiculoEntradaManualDTO dadosEntrada) {
        String placaLimpa = dadosEntrada.placa().toUpperCase().replace("-", "");
        registroRepository.findByVeiculoPlacaAndHorarioSaidaIsNull(placaLimpa)
                .ifPresent(r -> {
                    throw new IllegalStateException("ERRO: Este veículo já se encontra no pátio.");
                });
        Veiculo veiculo = veiculoRepository.findFirstByPlaca(placaLimpa).orElseGet(() -> {
            Veiculo novoVeiculo = new Veiculo();
            novoVeiculo.setPlaca(placaLimpa);
            return novoVeiculo;
        });
        if (veiculo.getId() == null && (dadosEntrada.nomeCliente() == null ||
                dadosEntrada.nomeCliente().isBlank())) {
            throw new IllegalArgumentException(
                    "O nome do cliente é obrigatório para o primeiro registro de um veículo.");
        }
        VeiculoDTO veiculoExterno = consultaExternaService.consultarPlaca(placaLimpa);
        if (veiculoExterno != null) {
            veiculo.setModelo(veiculoExterno.modelo());
            veiculo.setCor(veiculoExterno.cor());
            veiculo.setAno(veiculoExterno.ano());
        }
        if (dadosEntrada.nomeCliente() != null && !dadosEntrada.nomeCliente().isBlank()) {
            veiculo.setNomeCliente(dadosEntrada.nomeCliente());
        }
        if (dadosEntrada.telefoneCliente() != null) {
            veiculo.setTelefoneCliente(dadosEntrada.telefoneCliente());
        }
        veiculoRepository.save(veiculo);
        RegistroEstacionamento novoRegistro = new RegistroEstacionamento();
        novoRegistro.setVeiculo(veiculo);
        novoRegistro.setHorarioEntrada(LocalDateTime.now());
        registroRepository.save(novoRegistro);
    }

    @Transactional(readOnly = true)
    public List<VeiculoDTO> listarVeiculosAtivos() {
        return registroRepository.
                findByHorarioSaidaIsNullOrderByHorarioEntradaDesc()
                .stream()
                .map(this::mapearRegistroParaDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<VeiculoDTO> listarHistoricoCompleto() {
        return registroRepository.buscarHistoricoCompletoComOrdenacao()
                .stream()
                .map(this::mapearRegistroParaDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<VeiculoDTO> gerarRelatorioPorPlaca(String placa) {
        List<RegistroEstacionamento> registros = registroRepository
                .buscarHistoricoPorPlacaComOrdenacao(placa);
        return registros.stream()
                .map(this::mapearRegistroParaDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<VeiculoDTO> buscarRegistrosPorPeriodo(
            LocalDateTime dataInicio, LocalDateTime dataFim) {
        return registroRepository.findByHorarioEntradaBetweenOrderByHorarioEntradaDesc(
                        dataInicio, dataFim).stream()
                .map(this::mapearRegistroParaDTO)
                .collect(Collectors.toList());
    }

    private VeiculoDTO mapearRegistroParaDTO(RegistroEstacionamento reg) {
        Veiculo v = reg.getVeiculo();
        return new VeiculoDTO(
                v.getNomeCliente(), v.getTelefoneCliente(), v.getPlaca(), v.getModelo(),
                v.getCor(), v.getAno(), reg.getHorarioEntrada(), reg.getHorarioSaida(),
                reg.getValorTotal()
        );
    }

    // --- INÍCIO DO NOVO MÉTODO HELPER ---

    /**
     * Helper para formatar uma Duração em um texto (ex: "2h 15m")
     */
    private String formatarDuracao(Duration duracao) {
        if (duracao == null) {
            return "0m";
        }
        long totalMinutos = duracao.toMinutes();
        long horas = totalMinutos / 60;
        long minutos = totalMinutos % 60;

        if (horas > 0) {
            return String.format("%dh %dm", horas, minutos);
        } else {
            return String.format("%dm", minutos);
        }
    }

    // --- FIM DO NOVO MÉTODO HELPER ---
}