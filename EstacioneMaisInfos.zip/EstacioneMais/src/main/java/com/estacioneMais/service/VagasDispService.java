package com.estacioneMais.service;

import com.estacioneMais.dto.VagasDispDTO;
import com.estacioneMais.model.VagasDisp;
import com.estacioneMais.repository.VagasDispRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class VagasDispService {

    private final VagasDispRepository vagasDispRepository;

    public VagasDispService(VagasDispRepository vagasDispRepository) {
        this.vagasDispRepository = vagasDispRepository;
    }

    /**
     * Busca a configuração de vagas no banco. Se não existir, cria uma com um valor padrão.
     */
    @Transactional
    public VagasDisp getVagas() {
        // Tenta buscar a configuração de vagas
        return vagasDispRepository.findFirstByOrderByIdAsc()
                // Se não encontrar, cria uma nova com 20 vagas como padrão
                .orElseGet(() -> {
                    VagasDisp defaultVagas = new VagasDisp();
                    defaultVagas.setTotalVagas(20); // Valor padrão
                    return vagasDispRepository.save(defaultVagas);
                });
    }

    /**
     * Atualiza o total de vagas com o novo valor recebido do frontend.
     */
    @Transactional
    public VagasDispDTO atualizarVagas(VagasDispDTO dto) {
        // Busca a configuração existente (ou cria uma se não houver)
        VagasDisp vagasAtuais = getVagas();
        vagasAtuais.setTotalVagas(dto.totalVagas());
        VagasDisp vagasSalvas = vagasDispRepository.save(vagasAtuais);

        // Retorna um novo DTO a partir da entidade que foi salva no banco
        return new VagasDispDTO(vagasSalvas.getTotalVagas());
    }
}