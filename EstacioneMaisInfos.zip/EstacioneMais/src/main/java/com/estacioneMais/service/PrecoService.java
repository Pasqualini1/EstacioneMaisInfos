package com.estacioneMais.service;

import com.estacioneMais.dto.PrecoDTO;
import com.estacioneMais.model.Preco;
import com.estacioneMais.repository.PrecoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
public class PrecoService {
    // --- CORREÇÃO DE NOME: Variável renomeada para refletir o repositório correto ---
    private final PrecoRepository precoRepository;

    // --- CORREÇÃO DE NOME: Construtor ajustado ---
    public PrecoService(PrecoRepository precoRepository) {
        this.precoRepository = precoRepository;
    }

    /**
     * Busca as regras de preço no banco. Se não existirem, cria uma com valores padrão.
     */
    @Transactional
    // --- CORREÇÃO DE NOME: Método renomeado para maior clareza ---
    public Preco getPreco() {
        return precoRepository.findFirstByOrderByIdAsc().orElseGet(() -> {
            Preco defaultPreco = new Preco();
            defaultPreco.setPrecoValor(new BigDecimal("5.00")); // Valor padrão
            defaultPreco.setPrecoMinutos(60);                     // Tempo padrão (60 min = 1 hora)
            return precoRepository.save(defaultPreco);
        });
    }

    /**
     * Atualiza as regras de preço com os novos dados recebidos do frontend.
     * Retorna um DTO com os dados salvos para confirmar a operação.
     */
    @Transactional
    // --- CORREÇÃO DE NOME: Método renomeado para maior clareza ---
    public PrecoDTO atualizarPreco(PrecoDTO dto) {
        // --- CORREÇÃO DE NOME: Variável e chamada de método ajustadas ---
        Preco precoAtual = getPreco();
        precoAtual.setPrecoValor(dto.precoValor());
        precoAtual.setPrecoMinutos(dto.precoMinutos());
        Preco precoSalvo = precoRepository.save(precoAtual);

        // Retorna um novo DTO a partir da entidade que foi salva no banco
        return new PrecoDTO(precoSalvo.getPrecoValor(), precoSalvo.getPrecoMinutos());
    }
}