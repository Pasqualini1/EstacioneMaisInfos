package com.estacioneMais.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@Entity
// --- MUDANÇA CRUCIAL AQUI ---
// Esta anotação diz ao Hibernate para criar e usar uma tabela chamada "preco"
@Table(name = "preco")
public class Preco {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "preco_valor", nullable = false)
    private BigDecimal precoValor;

    @Column(name = "preco_minutos", nullable = false)
    private int precoMinutos;
}