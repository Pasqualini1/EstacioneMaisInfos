package com.estacioneMais.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * DTO para representar o status de um único veículo
 * que está atualmente no pátio (para o modal de informações).
 */
public record VeiculoStatusDTO(
        // Dados do Veículo e Cliente
        String placa,
        String nomeCliente,
        String telefoneCliente,
        String modelo,
        String cor,

        // Dados da Estadia
        LocalDateTime horarioEntrada,
        String tempoEstacionado, // (ex: "2h 30m")
        BigDecimal valorAtual    // (O valor calculado até o momento)
) {
}