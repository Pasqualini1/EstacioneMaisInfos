package dto;

/**
 * DTO (Data Transfer Object) para registrar a entrada de um veículo via imagem.
 *
 * Este record é usado para encapsular os dados enviados em uma requisição
 * quando o registro é feito a partir de uma foto, como a da webcam. Ele carrega
 * a imagem codificada e os dados opcionais do cliente.
 *
 * @param imagemBase64     A imagem capturada (da placa do veículo), codificada como uma string Base64.
 * @param nomeCliente      O nome do cliente/motorista, que é opcional neste fluxo.
 * @param telefoneCliente  O telefone de contato do cliente, também opcional.
 */
public record VeiculoEntradaDTO(String imagemBase64, String nomeCliente, String telefoneCliente) {}