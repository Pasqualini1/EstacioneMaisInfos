package dto;

import java.math.BigDecimal;

/**
 * DTO para transportar os dados de configuração de preços (simplificado).
 *
 * @param precoValor   O valor a ser cobrado (Ex: R$ 10,00).
 * @param precoMinutos A quantidade de minutos correspondente ao valor (Ex: 60 para 1 hora).
 */
public record PrecoDTO(
        BigDecimal precoValor,
        int precoMinutos
) {}