
package com.estacionemaisf;

import view.TelaEntradaVeiculo;
import view.TelaPrincipal;

public class EstacioneMaisF {

    public static void main(String[] args) {
            TelaPrincipal tela = new TelaPrincipal();
            tela.setVisible(true);
    }
}