package view;

import dto.VeiculoDTO;
import service.ApiClient;
import service.ApiException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class TelaGerenciarVeiculos extends JPanel {

    // --- Estilos ---
    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ACCENT = new Color(0, 173, 181);
    private static final Color COLOR_BUTTON_SAIDA = new Color(220, 53, 69);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private static final Font FONT_ROW = new Font("Segoe UI", Font.PLAIN, 14);

    // --- Componentes ---
    private final JTable tabela;
    private final DefaultTableModel modeloTabela;
    private final TelaPrincipal telaPrincipal;
    
    private int hoveredRow = -1;

    public TelaGerenciarVeiculos(TelaPrincipal telaPrincipal) {
        this.telaPrincipal = telaPrincipal;
        setLayout(new GridBagLayout());
        setBackground(COLOR_BACKGROUND);

        String[] colunas = {"Placa", "Cliente", "Modelo", "Cor", "Ano", "Entrada", "Status", "Ação"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == getColumnCount() - 1;
            }
        };
        tabela = new JTable(modeloTabela);

        tabela.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                int row = tabela.rowAtPoint(e.getPoint());
                int col = tabela.columnAtPoint(e.getPoint());
                int acaoColumnIndex = tabela.getColumnModel().getColumnIndex("Ação");

                if (row > -1 && col == acaoColumnIndex) {
                    if (row != hoveredRow) {
                        hoveredRow = row;
                        tabela.repaint();
                    }
                } else {
                    if (hoveredRow != -1) {
                        hoveredRow = -1;
                        tabela.repaint();
                    }
                }
            }
        });
        
        tabela.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent e) {
                if (hoveredRow != -1) {
                    hoveredRow = -1;
                    tabela.repaint();
                }
            }
        });

        add(createStyledCentralPanel(), new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(30, 30, 30, 30), 0, 0));

        carregarVeiculosAtivos();
    }

    private void carregarVeiculosAtivos() {
        modeloTabela.setRowCount(0);

        SwingWorker<List<VeiculoDTO>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<VeiculoDTO> doInBackground() throws ApiException {
                return ApiClient.listarVeiculosAtivos();
            }

            @Override
            protected void done() {
                try {
                    List<VeiculoDTO> veiculos = get();
                    for (VeiculoDTO v : veiculos) {
                        String clienteInfo = v.nomeCliente() + (v.telefoneCliente() !=
                                null && !v.telefoneCliente().isBlank() ?
                                " (" + v.telefoneCliente() + ")" : "");
                        modeloTabela.addRow(new Object[]{
                            v.placa(), clienteInfo, v.modelo(), v.cor(), v.ano(),
                            formatarData(v.horarioEntrada()), "No Pátio", "Registrar Saída"
                        });
                    }
                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() :
                            "Ocorreu um erro inesperado.";
                    DialogoCustomizado.mostrarMensagemErro(
                        (Frame) SwingUtilities.getWindowAncestor(TelaGerenciarVeiculos.this),
                        "Erro", "Erro ao carregar veículos:\n" + errorMessage
                    );
                }
            }
        };
        worker.execute();
    }

    private void registrarSaidaVeiculo(int row) {
        if (row < 0 || row >= modeloTabela.getRowCount()) return;
        String placa = (String) tabela.getValueAt(row, 0);
        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);

        SwingWorker<VeiculoDTO, Void> previewWorker = new SwingWorker<>() {
            @Override
            protected VeiculoDTO doInBackground() throws ApiException {
                return ApiClient.getPreviewSaida(placa);
            }

            @Override
            protected void done() {
                try {
                    VeiculoDTO preview = get();

                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yy 'às' HH:mm");
                    String mensagem = String.format(
                        "Placa: %s\n" +
                        "Entrada: %s\n" +
                        "Saída: %s\n\n" +
                        "Valor Total a Pagar: R$ %.2f",
                        preview.placa(),
                        preview.horarioEntrada().format(formatter),
                        preview.horarioSaida().format(formatter),
                        preview.valorTotal()
                    );

                    boolean confirm = DialogoCustomizado.mostrarConfirmacao(
                        owner,
                        "Confirmar Registro de Saída",
                        mensagem
                    );

                    if (confirm) {
                        confirmarRegistroSaida(placa);
                    }

                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() : "Ocorreu um erro inesperado.";
                    DialogoCustomizado.mostrarMensagemErro(owner, "Erro", "Não foi possível calcular o valor da saída:\n" + errorMessage);
                }
            }
        };
        previewWorker.execute();
    }

    private void confirmarRegistroSaida(String placa) {
        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);

        SwingWorker<Void, Void> finalWorker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() throws ApiException {
                ApiClient.registrarSaida(placa);
                return null;
            }

            @Override
            protected void done() {
                try {
                    get();
                    DialogoCustomizado.mostrarMensagemSucesso(
                        owner,
                        "Sucesso",
                        "Saída do veículo " + placa + " registrada com sucesso!"
                    );
                    carregarVeiculosAtivos();
                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() : "Ocorreu um erro inesperado.";
                    DialogoCustomizado.mostrarMensagemErro(owner, "Erro", "Erro ao confirmar a saída:\n" + errorMessage);
                }
            }
        };
        finalWorker.execute();
    }
    
    private String formatarData(LocalDateTime data) {
        if (data == null) return "N/A";
        return data.format(DateTimeFormatter.ofPattern("dd/MM/yy HH:mm"));
    }
    
    /**
     * Adicionado o método para carregar ícones de forma consistente.
     */
    private ImageIcon loadIcon(String path, int width, int height) {
        File file = new File(path);
        if (!file.exists()) {
            System.err.println("Imagem não encontrada: " + path);
            return new ImageIcon(new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB));
        }
        ImageIcon icon = new ImageIcon(path);
        if (width > 0 && height > 0) {
            Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
            icon = new ImageIcon(img);
        }
        return icon;
    }

    // --- MÉTODOS DE CONSTRUÇÃO DA UI ---

    private JPanel createStyledCentralPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_SHADOW);
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        panel.setBackground(COLOR_PANEL);
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(25, 25, 25, 25));
        panel.add(createTitlePanel(), BorderLayout.NORTH);
        panel.add(createTableScrollPane(), BorderLayout.CENTER);
        return panel;
    }
    
    private JPanel createTitlePanel() {
        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setOpaque(false);
        
        // --- CORREÇÃO APLICADA AQUI ---
        JLabel lblTitulo = new JLabel("Veículos Atualmente no Pátio");
        lblTitulo.setIcon(loadIcon("src/imagens/gerenciar_icon.png", 28, 28)); // Usa o ícone
        lblTitulo.setIconTextGap(10); // Espaço entre o ícone e o texto
        
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        panelTitulo.add(lblTitulo, BorderLayout.WEST);
        
        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        painelBotoes.setOpaque(false);
        JButton btnAtualizar = createIconButton("🔄", "Atualizar Lista");
        btnAtualizar.addActionListener(e -> carregarVeiculosAtivos());
        painelBotoes.add(btnAtualizar);
        JButton btnFechar = createIconButton("X", "Fechar");
        btnFechar.addActionListener(e -> telaPrincipal.mostrarPainelInicial());
        painelBotoes.add(btnFechar);
        panelTitulo.add(painelBotoes, BorderLayout.EAST);
        return panelTitulo;
    }
    
    private JScrollPane createTableScrollPane() {
        styleTable();
        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setBorder(BorderFactory.createLineBorder(COLOR_BACKGROUND, 1));
        scrollPane.getViewport().setBackground(COLOR_PANEL);
        return scrollPane;
    }
    
    private void styleTable() {
        tabela.setRowHeight(45);
        tabela.setFont(FONT_ROW);
        tabela.setForeground(COLOR_TEXT_PRIMARY);
        tabela.setBackground(COLOR_PANEL);
        tabela.setGridColor(COLOR_BACKGROUND);
        tabela.setSelectionBackground(COLOR_ACCENT.darker());
        tabela.setSelectionForeground(Color.WHITE);
        tabela.setFillsViewportHeight(true);
        tabela.setShowVerticalLines(false);
        JTableHeader header = tabela.getTableHeader();
        header.setBackground(COLOR_BACKGROUND);
        header.setForeground(COLOR_ACCENT);
        header.setFont(FONT_HEADER);
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 50));
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        DefaultTableCellRenderer leftRenderer = new DefaultTableCellRenderer();
        leftRenderer.setHorizontalAlignment(JLabel.LEFT);
        tabela.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
        tabela.getColumnModel().getColumn(1).setCellRenderer(leftRenderer);
        tabela.getColumnModel().getColumn(2).setCellRenderer(leftRenderer);
        tabela.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
        tabela.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);
        tabela.getColumnModel().getColumn(5).setCellRenderer(centerRenderer);
        tabela.getColumnModel().getColumn(6).setCellRenderer(centerRenderer);
        tabela.getColumn("Ação").setCellRenderer(new ButtonRenderer());
        tabela.getColumn("Ação").setCellEditor(new ButtonEditor(new JCheckBox()));
    }
    
    private JButton createIconButton(String icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
        button.setForeground(COLOR_TEXT_PRIMARY);
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        button.setBorder(null);
        button.setFocusPainted(false);
        return button;
    }

    private class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
            setFont(new Font("Segoe UI Symbol", Font.BOLD, 12));
            setForeground(Color.WHITE);
            setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            setText((value == null) ? "" : value.toString());
            setBackground(row == hoveredRow ? COLOR_BUTTON_SAIDA.brighter() : COLOR_BUTTON_SAIDA);
            return this;
        }
    }

    private class ButtonEditor extends DefaultCellEditor {
        protected JButton button;
        private int currentRow;
        private boolean isPushed;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(e -> fireEditingStopped());
            button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 12));
            button.setForeground(Color.WHITE);
            button.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            this.currentRow = row;
            button.setText(value == null ? "" : value.toString());
            button.setBackground(COLOR_BUTTON_SAIDA.darker());
            isPushed = true;
            return button;
        }

        @Override
        public Object getCellEditorValue() {
            if (isPushed) {
                registrarSaidaVeiculo(currentRow);
            }
            isPushed = false;
            return "Registrar Saída";
        }

        @Override
        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }
    }
}