package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Um painel que serve como um menu de configurações flutuante (popup).
 * Ele contém botões que dão acesso a diferentes janelas de configuração da aplicação.
 */
public class MenuConfiguracaoPanel extends JPanel {

    /**
     * Constrói o painel do menu, inicializando os botões e definindo as ações
     * que eles executam ao serem clicados.
     *
     * @param telaPrincipal A janela principal da aplicação, usada como "pai" para os diálogos.
     * @param parentWindow A janela flutuante (JWindow) que contém este painel, para que possa ser fechada.
     */
    public MenuConfiguracaoPanel(TelaPrincipal telaPrincipal, JWindow parentWindow) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(new Color(32, 32, 32));
        setBorder(BorderFactory.createLineBorder(new Color(50, 50, 50), 1));

        // --- Botão para Chave de Serviço (Token) ---
        JButton btnToken = new MenuButton("Configurar Chave de Serviço");
        btnToken.addActionListener(e -> {
            parentWindow.dispose();
            DialogChaveServico dialog = new DialogChaveServico(telaPrincipal);
            dialog.setVisible(true);
        });

        // --- Botão para Preços ---
        JButton btnPrecos = new MenuButton("Configurar Preço");
        btnPrecos.addActionListener(e -> {
            parentWindow.dispose();
            DialogConfigurarPrecos dialog = new DialogConfigurarPrecos(telaPrincipal);
            dialog.setVisible(true);
        });

        // --- Botão: Configurar Vagas ---
        JButton btnVagas = new MenuButton("Configurar Vagas");
        btnVagas.addActionListener(e -> {
            parentWindow.dispose();
            DialogConfigurarVagas dialog = new DialogConfigurarVagas(telaPrincipal);
            dialog.setVisible(true);
        });

        // Adiciona todos os botões ao painel
        add(btnToken);
        add(btnPrecos);
        add(btnVagas);
    }

    /**
     * Classe interna que representa um botão com o estilo de um item de menu,
     * com alinhamento à esquerda e efeito de hover.
     */
    private static class MenuButton extends JButton {
        private final Color defaultBg = new Color(32, 32, 32);
        private final Color hoverBg = new Color(50, 50, 50);

        public MenuButton(String text) {
            super(text);
            setFont(new Font("Segoe UI", Font.BOLD, 14));
            setForeground(new Color(240, 240, 240));
            setBackground(defaultBg);
            setOpaque(true);
            setBorder(new EmptyBorder(10, 15, 10, 15)); // Reduzido o padding direito
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setHorizontalAlignment(SwingConstants.LEFT);
            setContentAreaFilled(false);

            // --- CORREÇÃO CRÍTICA APLICADA AQUI ---
            // Esta linha permite que o botão estique sua largura para preencher o contêiner.
            // A altura máxima é definida pela altura preferida para não esticar verticalmente.
            setMaximumSize(new Dimension(Integer.MAX_VALUE, getPreferredSize().height));

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    setBackground(hoverBg);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    setBackground(defaultBg);
                }
            });
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            g.setColor(getBackground());
            g.fillRect(0, 0, getWidth(), getHeight());
            super.paintComponent(g);
        }
    }
}