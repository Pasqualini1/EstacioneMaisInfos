package view;

import dto.StatusPatioDTO;
import dto.VeiculoStatusDTO;
import service.ApiClient;
import service.ApiException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TelaInfosPatio extends JPanel {

    // --- Estilos (Copiados da TelaGerenciarVeiculos) ---
    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ACCENT = new Color(0, 173, 181);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private static final Font FONT_ROW = new Font("Segoe UI", Font.PLAIN, 14);

    // --- NOVOS Estilos para Vagas ---
    private static final Color COLOR_VAGA_DISPONIVEL = new Color(40, 167, 69); // Verde
    private static final Color COLOR_VAGA_OCUPADA = new Color(220, 53, 69); // Vermelho

    // --- Componentes ---
    private final TelaPrincipal telaPrincipal;
    private JPanel painelGridVagas; // Agora será do tipo WrapPanel
    private JLabel lblTotalVagas;
    private JLabel lblVagasOcupadas;
    private JLabel lblVagasDisponiveis;

    public TelaInfosPatio(TelaPrincipal telaPrincipal) {
        this.telaPrincipal = telaPrincipal;
        setLayout(new GridBagLayout());
        setBackground(COLOR_BACKGROUND);

        // Adiciona o painel central estilizado (como na TelaGerenciarVeiculos)
        add(createStyledCentralPanel(), new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(30, 30, 30, 30), 0, 0));

        // Carrega os dados da API assim que a tela for criada
        carregarStatusPatio();
    }

    /**
     * Carrega os dados do endpoint /status-patio e reconstrói a UI.
     * Usa SwingWorker para não travar a tela.
     */
    private void carregarStatusPatio() {
        // Mostra um feedback de carregamento (opcional)
        lblTotalVagas.setText("Total: ...");
        lblVagasOcupadas.setText("Ocupadas: ...");
        lblVagasDisponiveis.setText("Disponíveis: ...");
        painelGridVagas.removeAll();
        painelGridVagas.revalidate();
        painelGridVagas.repaint();

        SwingWorker<StatusPatioDTO, Void> worker = new SwingWorker<>() {
            @Override
            protected StatusPatioDTO doInBackground() throws ApiException {
                // Chama o novo método que precisamos adicionar no ApiClient
                return ApiClient.getStatusPatio();
            }

            @Override
            protected void done() {
                try {
                    StatusPatioDTO status = get();

                    // 1. Atualiza os contadores
                    lblTotalVagas.setText("Total de Vagas: " + status.totalVagas());
                    lblVagasOcupadas.setText("Ocupadas: " + status.vagasOcupadas());
                    lblVagasDisponiveis.setText("Disponíveis: " + status.vagasDisponiveis());

                    // 2. Adiciona os "carrinhos vermelhos" (ocupadas)
                    for (VeiculoStatusDTO veiculo : status.veiculosNoPatio()) {
                        painelGridVagas.add(createVagaPanel(veiculo));
                    }

                    // 3. Adiciona os "carrinhos verdes" (disponíveis)
                    for (int i = 0; i < status.vagasDisponiveis(); i++) {
                        painelGridVagas.add(createVagaPanel(null));
                    }

                    // 4. Atualiza o painel do grid
                    painelGridVagas.revalidate();
                    painelGridVagas.repaint();

                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() : "Ocorreu um erro inesperado.";
                    DialogoCustomizado.mostrarMensagemErro(
                            (Frame) SwingUtilities.getWindowAncestor(TelaInfosPatio.this),
                            "Erro", "Erro ao carregar status do pátio:\n" + errorMessage
                    );
                }
            }
        };
        worker.execute();
    }

    /**
     * Cria o painel principal com sombra e bordas arredondadas.
     * (Estrutura copiada da TelaGerenciarVeiculos)
     */
    private JPanel createStyledCentralPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_SHADOW);
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        panel.setBackground(COLOR_PANEL);
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(25, 25, 25, 25));

        // Adiciona o Título (Norte)
        panel.add(createTitlePanel(), BorderLayout.NORTH);
        // Adiciona o Conteúdo Principal (Contadores + Grid) (Centro)
        panel.add(createMainContentPanel(), BorderLayout.CENTER);
        return panel;
    }

    /**
     * Cria o painel de título com botões de Atualizar e Fechar.
     * (Estrutura copiada da TelaGerenciarVeiculos)
     */
    private JPanel createTitlePanel() {
        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setOpaque(false);

        JLabel lblTitulo = new JLabel("Status do Pátio");
        // (Certifique-se de ter um 'status_icon.png' na sua pasta 'src/imagens/')
        lblTitulo.setIcon(loadIcon("src/imagens/status_icon.png", 28, 28));
        lblTitulo.setIconTextGap(10);
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        panelTitulo.add(lblTitulo, BorderLayout.WEST);

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        painelBotoes.setOpaque(false);
        JButton btnAtualizar = createIconButton("🔄", "Atualizar Status");
        btnAtualizar.addActionListener(e -> carregarStatusPatio()); // Ação de atualizar
        painelBotoes.add(btnAtualizar);
        JButton btnFechar = createIconButton("X", "Fechar");
        btnFechar.addActionListener(e -> telaPrincipal.mostrarPainelInicial()); // Ação de fechar
        painelBotoes.add(btnFechar);
        panelTitulo.add(painelBotoes, BorderLayout.EAST);
        return panelTitulo;
    }

    /**
     * Cria o painel de conteúdo que agrupa os contadores e o grid de vagas.
     */
    private JPanel createMainContentPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setOpaque(false);
        // Adiciona os contadores (Norte)
        mainPanel.add(createCountersPanel(), BorderLayout.NORTH);
        // Adiciona o grid rolável (Centro)
        mainPanel.add(createPatioGridScrollPane(), BorderLayout.CENTER);
        return mainPanel;
    }

    /**
     * Cria o painel de contadores (Total, Ocupadas, Disponíveis).
     */
    private JPanel createCountersPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 50, 10));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, COLOR_BACKGROUND.brighter()));

        lblTotalVagas = new JLabel("Total: --");
        lblVagasOcupadas = new JLabel("Ocupadas: --");
        lblVagasDisponiveis = new JLabel("Disponíveis: --");

        Font fontContador = new Font("Segoe UI", Font.BOLD, 18);
        lblTotalVagas.setFont(fontContador);
        lblTotalVagas.setForeground(COLOR_TEXT_PRIMARY);
        lblVagasOcupadas.setFont(fontContador);
        lblVagasOcupadas.setForeground(COLOR_VAGA_OCUPADA); // Cor vermelha
        lblVagasDisponiveis.setFont(fontContador);
        lblVagasDisponiveis.setForeground(COLOR_VAGA_DISPONIVEL); // Cor verde

        panel.add(lblTotalVagas);
        panel.add(lblVagasOcupadas);
        panel.add(lblVagasDisponiveis);
        return panel;
    }

    /**
     * Cria o painel de grid rolável onde os "carrinhos" serão desenhados.
     */
    private JScrollPane createPatioGridScrollPane() {
        // Usa o novo WrapPanel em vez de um JPanel comum.
        painelGridVagas = new WrapPanel(new FlowLayout(FlowLayout.LEFT, 20, 20));
        
        // Um fundo mais escuro para o grid
        painelGridVagas.setBackground(COLOR_PANEL.darker());
        painelGridVagas.setBorder(new EmptyBorder(10, 10, 10, 10));

        JScrollPane scrollPane = new JScrollPane(painelGridVagas);
        scrollPane.setBorder(BorderFactory.createLineBorder(COLOR_BACKGROUND, 1));
        scrollPane.getViewport().setBackground(COLOR_PANEL.darker());

        // Força a barra de rolagem horizontal a NUNCA aparecer
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        // E a barra vertical a aparecer SÓ se precisar
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        return scrollPane;
    }


    // --- MÉTODO ATUALIZADO (com as 3 correções) ---
    /**
     * Cria o painel individual de cada vaga (o "carrinho").
     * @param veiculo O VeiculoStatusDTO se a vaga estiver ocupada, ou null se estiver livre.
     */
    private JPanel createVagaPanel(VeiculoStatusDTO veiculo) {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        
        // --- CORREÇÃO 1: Definir um tamanho fixo para o "carrinho" ---
        Dimension vagaSize = new Dimension(130, 90);
        panel.setPreferredSize(vagaSize);
        panel.setMinimumSize(vagaSize); // Impede o FlowLayout de encolher o painel
        
        panel.setBorder(BorderFactory.createLineBorder(COLOR_BACKGROUND.brighter()));

        JLabel iconLabel = new JLabel();
        iconLabel.setHorizontalAlignment(SwingConstants.CENTER);
        
        // --- CORREÇÃO 2: Remover o fundo branco do ícone ---
        iconLabel.setOpaque(false);

        if (veiculo != null) {
            // VAGA OCUPADA (Vermelha)
            panel.setBackground(COLOR_VAGA_OCUPADA);
            iconLabel.setIcon(loadIcon("src/imagens/car_icon_red.png", 40, 40));
            panel.setCursor(new Cursor(Cursor.HAND_CURSOR));
            panel.setToolTipText("Placa: " + veiculo.placa() + " - Clique para ver detalhes");

            // Adiciona a placa na parte de baixo
            JLabel textLabel = new JLabel(veiculo.placa());
            textLabel.setFont(FONT_ROW);
            textLabel.setForeground(Color.WHITE);
            textLabel.setHorizontalAlignment(SwingConstants.CENTER);
            
            panel.add(iconLabel, BorderLayout.CENTER);
            panel.add(textLabel, BorderLayout.SOUTH);
            
            // Adiciona a ação de clique para abrir o popup
            panel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    mostrarDetalhesVeiculo(veiculo);
                }
            });
        } else {
            // VAGA DISPONÍVEL (Verde)
            panel.setBackground(COLOR_VAGA_DISPONIVEL);
            iconLabel.setIcon(loadIcon("src/imagens/car_icon_green.png", 40, 40));
            panel.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            
            // --- CORREÇÃO 3: Deixar somente o ícone (sem texto "Disponível") ---
            // Adiciona o ícone ao centro (ele vai se centralizar verticalmente)
            panel.add(iconLabel, BorderLayout.CENTER);
        }

        return panel;
    }
    
    /**
     * Exibe o popup (DialogoCustomizado) com as informações do veículo.
     */
    private void mostrarDetalhesVeiculo(VeiculoStatusDTO veiculo) {
        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yy 'às' HH:mm");
        
        String mensagem = String.format(
            "Placa: %s\n" +
            "Cliente: %s\n" +
            "Telefone: %s\n" +
            "Modelo: %s (%s)\n\n" +
            "Entrada: %s\n" +
            "Tempo no Pátio: %s\n" +
            "Valor Atual: R$ %.2f",
            veiculo.placa(),
            veiculo.nomeCliente() != null ? veiculo.nomeCliente() : "Não informado",
            veiculo.telefoneCliente() != null ? veiculo.telefoneCliente() : "Não informado",
            veiculo.modelo() != null ? veiculo.modelo() : "Não informado",
            veiculo.cor() != null ? veiculo.cor() : "N/A",
            veiculo.horarioEntrada().format(formatter),
            veiculo.tempoEstacionado(),
            veiculo.valorAtual()
        );
        
        // Usando o 'mostrarMensagemSucesso' como um diálogo de "Info"
        DialogoCustomizado.mostrarMensagemSucesso(
            owner, 
            "Detalhes do Veículo", 
            mensagem
        );
    }

    // --- MÉTODOS HELPER (Copiados da TelaGerenciarVeiculos) ---

    private ImageIcon loadIcon(String path, int width, int height) {
        File file = new File(path);
        if (!file.exists()) {
            System.err.println("Imagem não encontrada: " + path);
            return new ImageIcon(new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB));
        }
        ImageIcon icon = new ImageIcon(path);
        if (width > 0 && height > 0) {
            Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
            icon = new ImageIcon(img);
        }
        return icon;
    }

    private JButton createIconButton(String icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
        button.setForeground(COLOR_TEXT_PRIMARY);
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        button.setBorder(null);
        button.setFocusPainted(false);
        return button;
    }
    
    // --- CLASSE INTERNA (NÃO MUDOU) ---
    /**
     * Um JPanel com FlowLayout que "quebra a linha" (wraps) dentro de um JScrollPane.
     * Ele faz isso implementando Scrollable e forçando sua largura a ser a da viewport.
     */
    private class WrapPanel extends JPanel implements Scrollable {
        
        public WrapPanel(LayoutManager layout) {
            super(layout);
        }
        
        @Override
        public Dimension getPreferredSize() {
            // Deixa o FlowLayout calcular a altura necessária
            // para a largura *atual* do painel (que é forçada pela viewport)
            return getLayout().preferredLayoutSize(this);
        }

        @Override
        public Dimension getPreferredScrollableViewportSize() {
            return getPreferredSize();
        }
        
        @Override
        public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction) {
            return 16; // Scroll de 16 pixels por vez
        }
        
        @Override
        public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction) {
            return 16; // Scroll de 16 pixels por vez
        }
        
        @Override
        public boolean getScrollableTracksViewportWidth() {
            // ESTA É A MÁGICA:
            // Força a largura do painel a ser igual à largura da viewport.
            // Isso "liga" o word-wrap do FlowLayout.
            return true;
        }
        
        @Override
        public boolean getScrollableTracksViewportHeight() {
            // Deixa a altura ser flexível (desliga o "wrap" vertical)
            // Isso permite que a barra de rolagem vertical apareça se necessário
            return false;
        }
    }
}