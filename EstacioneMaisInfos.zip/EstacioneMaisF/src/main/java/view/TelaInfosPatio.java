package view;

import dto.StatusPatioDTO;
import dto.VeiculoStatusDTO;
import service.ApiClient;
import service.ApiException;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TelaInfosPatio extends JPanel {

    // --- Estilos ---
    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_PANEL = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ACCENT = new Color(0, 173, 181);
    private static final Color COLOR_SHADOW = new Color(0, 0, 0, 80);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private static final Font FONT_ROW = new Font("Segoe UI", Font.PLAIN, 14);

    // --- Estilos de Vagas (usados apenas para texto/ícone agora) ---
    private static final Color COLOR_VAGA_DISPONIVEL = new Color(40, 167, 69); // Verde
    private static final Color COLOR_VAGA_OCUPADA = new Color(220, 53, 69); // Vermelho

    // --- Componentes ---
    private final TelaPrincipal telaPrincipal;
    private JPanel painelGridVagas;
    private JLabel lblTotalVagas;
    private JLabel lblVagasOcupadas;
    private JLabel lblVagasDisponiveis;

    public TelaInfosPatio(TelaPrincipal telaPrincipal) {
        this.telaPrincipal = telaPrincipal;
        setLayout(new GridBagLayout());
        setBackground(COLOR_BACKGROUND);

        add(createStyledCentralPanel(), new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(30, 30, 30, 30), 0, 0));

        carregarStatusPatio();
    }
    
    private void carregarStatusPatio() {
        lblTotalVagas.setText("Total: ...");
        lblVagasOcupadas.setText("Ocupadas: ...");
        lblVagasDisponiveis.setText("Disponíveis: ...");
        painelGridVagas.removeAll();
        painelGridVagas.revalidate();
        painelGridVagas.repaint();

        SwingWorker<StatusPatioDTO, Void> worker = new SwingWorker<>() {
            @Override
            protected StatusPatioDTO doInBackground() throws ApiException {
                return ApiClient.getStatusPatio();
            }

            @Override
            protected void done() {
                try {
                    StatusPatioDTO status = get();

                    lblTotalVagas.setText("Total de Vagas: " + status.totalVagas());
                    lblVagasOcupadas.setText("Ocupadas: " + status.vagasOcupadas());
                    lblVagasDisponiveis.setText("Disponíveis: " + status.vagasDisponiveis());

                    // Preenche o grid
                    for (VeiculoStatusDTO veiculo : status.veiculosNoPatio()) {
                        painelGridVagas.add(createVagaPanel(veiculo));
                    }
                    for (int i = 0; i < status.vagasDisponiveis(); i++) {
                        painelGridVagas.add(createVagaPanel(null));
                    }

                    painelGridVagas.revalidate();
                    painelGridVagas.repaint();

                } catch (Exception e) {
                    Throwable cause = e.getCause();
                    String errorMessage = (cause instanceof ApiException) ? cause.getMessage() : "Ocorreu um erro inesperado.";
                    DialogoCustomizado.mostrarMensagemErro(
                            (Frame) SwingUtilities.getWindowAncestor(TelaInfosPatio.this),
                            "Erro", "Erro ao carregar status do pátio:\n" + errorMessage
                    );
                }
            }
        };
        worker.execute();
    }
    
    private JPanel createStyledCentralPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(COLOR_SHADOW);
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 20, 20);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
            }
        };
        panel.setBackground(COLOR_PANEL);
        panel.setOpaque(false);
        panel.setBorder(new EmptyBorder(25, 25, 25, 25));

        panel.add(createTitlePanel(), BorderLayout.NORTH);
        panel.add(createMainContentPanel(), BorderLayout.CENTER);
        return panel;
    }
    
    private JPanel createTitlePanel() {
        JPanel panelTitulo = new JPanel(new BorderLayout());
        panelTitulo.setOpaque(false);

        JLabel lblTitulo = new JLabel("Status do Pátio");
        lblTitulo.setIcon(loadIcon("src/imagens/status_icon.png", 28, 28));
        lblTitulo.setIconTextGap(10);
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        panelTitulo.add(lblTitulo, BorderLayout.WEST);

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        painelBotoes.setOpaque(false);
        JButton btnAtualizar = createIconButton("🔄", "Atualizar Status");
        btnAtualizar.addActionListener(e -> carregarStatusPatio());
        painelBotoes.add(btnAtualizar);
        JButton btnFechar = createIconButton("X", "Fechar");
        btnFechar.addActionListener(e -> telaPrincipal.mostrarPainelInicial());
        painelBotoes.add(btnFechar);
        panelTitulo.add(painelBotoes, BorderLayout.EAST);
        return panelTitulo;
    }
    
    private JPanel createMainContentPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setOpaque(false);
        mainPanel.add(createCountersPanel(), BorderLayout.NORTH);
        mainPanel.add(createPatioGridScrollPane(), BorderLayout.CENTER);
        return mainPanel;
    }
    
    private JPanel createCountersPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 50, 10));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, COLOR_BACKGROUND.brighter()));

        lblTotalVagas = new JLabel("Total: --");
        lblVagasOcupadas = new JLabel("Ocupadas: --");
        lblVagasDisponiveis = new JLabel("Disponíveis: --");

        Font fontContador = new Font("Segoe UI", Font.BOLD, 18);
        lblTotalVagas.setFont(fontContador);
        lblTotalVagas.setForeground(COLOR_TEXT_PRIMARY);
        lblVagasOcupadas.setFont(fontContador);
        lblVagasOcupadas.setForeground(COLOR_VAGA_OCUPADA); // Cor vermelha
        lblVagasDisponiveis.setFont(fontContador);
        lblVagasDisponiveis.setForeground(COLOR_VAGA_DISPONIVEL); // Cor verde

        panel.add(lblTotalVagas);
        panel.add(lblVagasOcupadas);
        panel.add(lblVagasDisponiveis);
        return panel;
    }

    // --- MÉTODO ATUALIZADO ---
    /**
     * Cria o painel de grid rolável onde os "carrinhos" serão desenhados.
     */
    private JScrollPane createPatioGridScrollPane() {
        // --- CORREÇÃO 1: Usar GridLayout ---
        // Cria um grid com 6 colunas, linhas dinâmicas, e 20px de espaçamento
        int numColunas = 6;
        painelGridVagas = new JPanel(new GridLayout(0, numColunas, 20, 20));
        
        painelGridVagas.setBackground(COLOR_PANEL.darker());
        painelGridVagas.setBorder(new EmptyBorder(20, 20, 20, 20)); // Aumentar o padding

        JScrollPane scrollPane = new JScrollPane(painelGridVagas);
        scrollPane.setBorder(BorderFactory.createLineBorder(COLOR_BACKGROUND, 1));
        scrollPane.getViewport().setBackground(COLOR_PANEL.darker());
        
        // --- REMOÇÃO ---
        // Não precisamos mais forçar a política da barra de rolagem,
        // pois o GridLayout não vai criar uma barra horizontal.
        
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        return scrollPane;
    }

    // --- MÉTODO ATUALIZADO ---
    /**
     * Cria o painel individual de cada vaga (o "carrinho").
     * @param veiculo O VeiculoStatusDTO se a vaga estiver ocupada, ou null se estiver livre.
     */
    private JPanel createVagaPanel(VeiculoStatusDTO veiculo) {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        
        // Define um tamanho fixo para o "carrinho"
        Dimension vagaSize = new Dimension(130, 90);
        panel.setPreferredSize(vagaSize);
        panel.setMinimumSize(vagaSize); 
        
        // --- CORREÇÃO 2: Remover o fundo verde/vermelho ---
        // O painel agora é transparente, mostrando a cor de fundo (COLOR_PANEL.darker())
        panel.setOpaque(false);
        // Deixamos uma borda sutil para definir o espaço
        panel.setBorder(BorderFactory.createLineBorder(COLOR_BACKGROUND.brighter()));

        JLabel iconLabel = new JLabel();
        iconLabel.setHorizontalAlignment(SwingConstants.CENTER);
        iconLabel.setOpaque(false); // Garante que o JLabel do ícone também é transparente

        if (veiculo != null) {
            // VAGA OCUPADA
            iconLabel.setIcon(loadIcon("src/imagens/car_icon_red.png", 40, 40));
            panel.setCursor(new Cursor(Cursor.HAND_CURSOR));
            panel.setToolTipText("Placa: " + veiculo.placa() + " - Clique para ver detalhes");

            // Adiciona a placa na parte de baixo
            JLabel textLabel = new JLabel(veiculo.placa());
            textLabel.setFont(new Font("Segoe UI", Font.BOLD, 14)); // Fonte maior
            textLabel.setForeground(COLOR_VAGA_OCUPADA); // Placa com cor vermelha
            textLabel.setHorizontalAlignment(SwingConstants.CENTER);
            
            panel.add(iconLabel, BorderLayout.CENTER);
            panel.add(textLabel, BorderLayout.SOUTH);
            
            panel.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    mostrarDetalhesVeiculo(veiculo);
                }
            });
        } else {
            // VAGA DISPONÍVEL
            iconLabel.setIcon(loadIcon("src/imagens/car_icon_green.png", 40, 40));
            panel.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            
            // Texto da placa vazio para manter o alinhamento
            JLabel textLabel = new JLabel(" ");
            textLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
            panel.add(textLabel, BorderLayout.SOUTH);
            
            panel.add(iconLabel, BorderLayout.CENTER);
        }

        return panel;
    }
    
    private void mostrarDetalhesVeiculo(VeiculoStatusDTO veiculo) {
        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yy 'às' HH:mm");
        
        String mensagem = String.format(
            "Placa: %s\n" +
            "Cliente: %s\n" +
            "Telefone: %s\n" +
            "Modelo: %s (%s)\n\n" +
            "Entrada: %s\n" +
            "Tempo no Pátio: %s\n" +
            "Valor Atual: R$ %.2f",
            veiculo.placa(),
            veiculo.nomeCliente() != null ? veiculo.nomeCliente() : "Não informado",
            veiculo.telefoneCliente() != null ? veiculo.telefoneCliente() : "Não informado",
            veiculo.modelo() != null ? veiculo.modelo() : "Não informado",
            veiculo.cor() != null ? veiculo.cor() : "N/A",
            veiculo.horarioEntrada().format(formatter),
            veiculo.tempoEstacionado(),
            veiculo.valorAtual()
        );
        
        DialogoCustomizado.mostrarMensagemSucesso(
            owner, 
            "Detalhes do Veículo", 
            mensagem
        );
    }

    // --- MÉTODOS HELPER ---

    private ImageIcon loadIcon(String path, int width, int height) {
        File file = new File(path);
        if (!file.exists()) {
            System.err.println("Imagem não encontrada: " + path);
            return new ImageIcon(new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB));
        }
        ImageIcon icon = new ImageIcon(path);
        if (width > 0 && height > 0) {
            Image img = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
            icon = new ImageIcon(img);
        }
        return icon;
    }

    private JButton createIconButton(String icon, String tooltip) {
        JButton button = new JButton(icon);
        button.setFont(new Font("Segoe UI Symbol", Font.BOLD, 16));
        button.setForeground(COLOR_TEXT_PRIMARY);
        button.setToolTipText(tooltip);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        button.setBorder(null);
        button.setFocusPainted(false);
        return button;
    }

}