package view;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TelaVisualizadorPdf extends JPanel {

    // --- Estilos ---
    private static final Color COLOR_BACKGROUND = new Color(34, 40, 49);
    private static final Color COLOR_TOP_BAR = new Color(57, 62, 70);
    private static final Color COLOR_TEXT_PRIMARY = new Color(238, 238, 238);
    private static final Color COLOR_ORANGE_ACCENT = new Color(255, 157, 8);
    private static final Color COLOR_INPUT_BG = new Color(45, 45, 45);
    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 18);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    // --- Componentes ---
    private final TelaPrincipal telaPrincipal;
    private final byte[] pdfBytes;
    private final JPanel painelPaginas;
    private final JScrollPane scrollPane;
    // --- 1. NOVA VARIÁVEL PARA GUARDAR O NOME DO ARQUIVO ---
    private final String defaultFileName;

    /**
     * --- 2. CONSTRUTOR ATUALIZADO ---
     * Agora ele recebe um nome de arquivo padrão.
     */
    public TelaVisualizadorPdf(TelaPrincipal telaPrincipal, byte[] pdfBytes, String defaultFileName) {
        this.telaPrincipal = telaPrincipal;
        this.pdfBytes = pdfBytes;
        this.defaultFileName = defaultFileName; // Guarda o nome recebido

        setLayout(new BorderLayout());
        setBackground(COLOR_BACKGROUND);

        painelPaginas = new JPanel();
        painelPaginas.setLayout(new BoxLayout(painelPaginas, BoxLayout.Y_AXIS));
        painelPaginas.setBackground(COLOR_BACKGROUND);

        scrollPane = new JScrollPane(painelPaginas);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        add(createTopPanel(), BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        carregarPdf();
    }

    private void salvarPdf() {
        // --- 3. CORREÇÃO APLICADA AQUI ---
        // Usa a variável com o nome do arquivo em vez de um texto fixo.
        File fileToSave = CustomFileChooser.showSaveDialog(this, this.defaultFileName);

        if (fileToSave != null) {
            try (FileOutputStream fos = new FileOutputStream(fileToSave)) {
                fos.write(this.pdfBytes);
                
                boolean abrir = DialogoCustomizado.mostrarConfirmacao(
                    (Frame) SwingUtilities.getWindowAncestor(this),
                    "Sucesso",
                    "PDF salvo com sucesso! Deseja abrir o arquivo?"
                );
                
                if (abrir) {
                    if (Desktop.isDesktopSupported()) {
                        Desktop.getDesktop().open(fileToSave);
                    } else {
                        DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(this),
                                "Aviso", "Não foi possível abrir o arquivo automaticamente.");
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
                DialogoCustomizado.mostrarMensagemErro((Frame) SwingUtilities.getWindowAncestor(this), "Erro",
                        "Ocorreu um erro ao salvar o PDF.");
            }
        }
    }

    private void carregarPdf() {
        JLabel lblCarregando = new JLabel("Renderizando PDF, por favor aguarde...");
        lblCarregando.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblCarregando.setForeground(Color.WHITE);
        lblCarregando.setHorizontalAlignment(SwingConstants.CENTER);
        painelPaginas.add(lblCarregando);

        SwingWorker<List<BufferedImage>, Void> worker = new SwingWorker<>() {
            @Override
            protected List<BufferedImage> doInBackground() throws Exception {
                List<BufferedImage> paginas = new ArrayList<>();
                try (PDDocument document = PDDocument.load(pdfBytes)) {
                    PDFRenderer pdfRenderer = new PDFRenderer(document);
                    for (int i = 0; i < document.getNumberOfPages(); i++) {
                        paginas.add(pdfRenderer.renderImageWithDPI(i, 150));
                    }
                }
                return paginas;
            }
            @Override
            protected void done() {
                try {
                    List<BufferedImage> imagensPaginas = get();
                    painelPaginas.removeAll();

                    for (BufferedImage imagem : imagensPaginas) {
                        JLabel lblPagina = new JLabel(new ImageIcon(imagem));
                        lblPagina.setBorder(new EmptyBorder(0, 0, 15, 0));
                        painelPaginas.add(lblPagina);
                    }
                    
                    painelPaginas.revalidate();
                    painelPaginas.repaint();
                    SwingUtilities.invokeLater(() -> scrollPane.getVerticalScrollBar().setValue(0));
                } catch (Exception e) {
                    e.printStackTrace();
                    painelPaginas.removeAll();
                    lblCarregando.setText("Erro ao carregar o PDF.");
                    painelPaginas.add(lblCarregando);
                    painelPaginas.revalidate();
                    painelPaginas.repaint();
                }
            }
        };
        worker.execute();
    }

    private JPanel createTopPanel() {
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(new EmptyBorder(10, 15, 10, 15));
        topPanel.setBackground(COLOR_TOP_BAR);

        JLabel lblTitulo = new JLabel("Visualizador de Relatório");
        lblTitulo.setFont(FONT_TITLE);
        lblTitulo.setForeground(COLOR_TEXT_PRIMARY);
        topPanel.add(lblTitulo, BorderLayout.WEST);

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonsPanel.setOpaque(false);

        RoundedButton btnSalvar = new RoundedButton("Salvar PDF");
        btnSalvar.setBackground(COLOR_ORANGE_ACCENT);
        btnSalvar.addActionListener(e -> salvarPdf());
        buttonsPanel.add(btnSalvar);

        RoundedButton btnVoltar = new RoundedButton("Voltar");
        btnVoltar.addActionListener(e -> telaPrincipal.trocarPainelCentral(new TelaRelatorios(telaPrincipal)));
        buttonsPanel.add(btnVoltar);
        
        topPanel.add(buttonsPanel, BorderLayout.EAST);

        return topPanel;
    }

    private class RoundedButton extends JButton {
        private Color defaultBg;
        private Color hoverBg;

        public RoundedButton(String text) {
            super(text);
            setFont(FONT_BUTTON);
            setForeground(Color.WHITE);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setFocusPainted(false);
            setBorder(new EmptyBorder(10, 20, 10, 20));
            setContentAreaFilled(false);
            
            this.defaultBg = COLOR_INPUT_BG;
            this.hoverBg = defaultBg.brighter();
            setBackground(defaultBg);

            addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    if (isEnabled()) {
                        setBackground(hoverBg);
                    }
                }
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    setBackground(defaultBg);
                }
            });
        }
        
        @Override
        public void setBackground(Color bg) {
            if (bg != hoverBg) {
                this.defaultBg = bg;
                this.hoverBg = bg.brighter();
            }
            super.setBackground(bg);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            if (getModel().isPressed()) {
                g2.setColor(getBackground().darker());
            }
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
            super.paintComponent(g2);
            g2.dispose();
        }
    }
}